Results and Plots
